<?php $__env->startSection('title', "Pelanggan"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="p-8 mobile:p-4 flex flex-col gap-4">
    <div class="flex items-center mobile:flex-row-reverse gap-4 w-full p-2 bg-white rounded-lg">
        <!-- Scrollable Tabs -->
        <div class="flex overflow-x-auto gap-2 pr-4 scrollbar-hide max-w-full">
            <a href="?tab=customer" class="p-3 px-6 mobile:px-4 whitespace-nowrap rounded-lg text-sm mobile:text-xs <?php echo e(($tab == '' || $tab == 'customer') ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
                Pelanggan
            </a>
            <a href="?tab=customer_type" class="p-3 px-6 mobile:px-4 whitespace-nowrap rounded-lg text-sm mobile:text-xs <?php echo e(in_array($tab, ['customer_type', 'customer_type_detail']) ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
                Tipe Pelanggan
            </a>
            <a href="?tab=review" class="p-3 px-6 mobile:px-4 whitespace-nowrap rounded-lg text-sm mobile:text-xs <?php echo e($tab == 'review' ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
                Ulasan Pelangan
            </a>
            
        </div>

        <!-- Fixed Action Button -->
        <div class="ml-auto shrink-0">
            <?php if($tab == "customer"): ?>
                <button class="bg-green-500 text-sm text-white font-medium p-3 px-4 rounded-lg flex items-center gap-2 whitespace-nowrap" onclick="toggleHidden('#AddCustomer')">
                    <ion-icon name="add-outline" class="text-lg"></ion-icon>
                    <div class="mobile:hidden">Tambah Pelanggan</div>
                    <div class="desktop:hidden text-xs">Pelanggan</div>
                </button>
            <?php endif; ?>
            <?php if($tab == "customer_type"): ?>
                <button class="bg-green-500 text-sm text-white font-medium p-3 px-4 rounded-lg flex items-center gap-2 whitespace-nowrap" onclick="toggleHidden('#AddEditType')">
                    <ion-icon name="add-outline" class="text-lg"></ion-icon>
                    <div class="mobile:hidden">Tambah Tipe Pelanggan</div>
                    <div class="desktop:hidden text-xs">Tipe</div>
                </button>
            <?php endif; ?>
            <?php if($tab == "customer_type_detail"): ?>
                <button class="bg-green-500 text-sm text-white font-medium p-3 px-4 rounded-lg flex items-center gap-2 whitespace-nowrap" onclick="toggleHidden('#AddCustomerToType')">
                    <ion-icon name="add-outline" class="text-lg"></ion-icon>
                    <div class="mobile:hidden">Tambah Pelanggan ke <?php echo e($type->name); ?></div>
                    <div class="desktop:hidden text-xs"> ke <?php echo e($type->name); ?></div>
                </button>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('user.customer.' . $tab, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>

<?php echo $__env->make('user.customer.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
<?php echo $__env->make('user.customer.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
<?php echo $__env->make('user.customer.customer_type_add_edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('user.customer.customer_type_delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('user.customer.customer_type_rename', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php if($type != null): ?>
    <?php echo $__env->make('user.customer.remove_customer_from_type', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('user.customer.customer_type_add_customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/MultiSelector.js')); ?>"></script>
<script src="<?php echo e(asset('js/MultiSelectorAPI.js')); ?>"></script>
<script>
    let isEditing = false;

    const Cancel = (target) => {
        toggleHidden(target);
        if (isEditing) {
            select("#AddSupplier #title").innerHTML = "Tambah Supplier";
            isEditing = false;
        }
    }

    function toggleContextMenu(event, id) {
        event.stopPropagation();

        // Close all other context menus
        document.querySelectorAll('[id^="ContextMenu"]').forEach(menu => {
            if (menu.id !== id) menu.classList.add('hidden');
        });

        const menu = document.getElementById(id);
        menu.classList.toggle('hidden');
    }

    // Click outside to close
    document.addEventListener('click', function () {
        document.querySelectorAll('[id^="ContextMenu"]').forEach(menu => {
            menu.classList.add('hidden');
        });
    });

    const RemoveCustomerFromType = (event, customer, type) => {
        const link = event.currentTarget;
        event.preventDefault();
        customer = JSON.parse(customer);
        type = JSON.parse(type);
        
        select("#RemoveCustomer #name").innerHTML = customer.name;
        select("#RemoveCustomer #type").innerHTML = type.name;
        select("#RemoveCustomer form").setAttribute('action', link.href);

        toggleHidden("#RemoveCustomer");
    }

    const DeleteCustomer = (event, data) => {
        event.preventDefault();
        const link = event.currentTarget;
        data = JSON.parse(data);
        select("#DeleteCustomer #name").innerHTML = data.name;
        select("#DeleteCustomer form").setAttribute('action', link.href);
        toggleHidden("#DeleteCustomer");
    }
    const DeleteCustomerType = data => {
        data = JSON.parse(data);
        select("#DeleteCustomerType #id").value = data.id;
        select("#DeleteCustomerType #name").innerHTML = data.name;
        toggleHidden("#DeleteCustomerType");
    }

    const types = <?php echo json_encode($types, 15, 512) ?>;
    new MultiSelector('#CustomerTypeSelector', types, {
		name: 'type_ids',
		label: 'Tipe Pelanggan',
		placeholder: 'Ketik nama tipe...'
	});
    if (select('#CustomerSelector') !== null) {
        new MultiSelectorAPI('#CustomerSelector', [], {
            fetchUrl: '/api/customer/search?branch_id=<?php echo e($me->access->branch_id); ?>&q=',
            name: "customer_ids",
            label: "Pelanggan",
            parseResponse: (data) => data.customers // if the response is { categories: [...] }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/customer/index.blade.php ENDPATH**/ ?>