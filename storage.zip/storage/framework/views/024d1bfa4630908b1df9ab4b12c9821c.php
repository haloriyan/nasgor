<?php $__env->startSection('title', "Laporan Pembelian"); ?>

<?php
    use Carbon\Carbon;
?>
    
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/airbnb.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<input type="hidden" id="startDate" value="<?php echo e($startDate); ?>">
<input type="hidden" id="endDate" value="<?php echo e($endDate); ?>">

<div class="p-8 flex flex-col gap-8">
    <div class="bg-white rounded-lg p-2 flex items-center gap-4 px-4">
        <div class="flex flex-col border rounded-lg p-2 grow mobile:w-full">
            <div class="text-xs text-slate-500">Cari No. Pembelian</div>
            <form class="flex items-center gap-4" onsubmit="searchProduct(event)">
                <button class="flex items-center">
                    <ion-icon name="search-outline" class="text-lg text-slate-700"></ion-icon>
                </button>
                <input type="text" id="q" name="q" class="h-8 outline-0 text-xs text-slate-600 w-full" value="<?php echo e($request->q); ?>">
                <?php if($request->q != ""): ?>
                    <div class="flex items-center cursor-pointer" onclick="addFilter({q: null})">
                        <ion-icon name="close-outline" class="text-red-500 text-lg"></ion-icon>
                    </div>
                <?php endif; ?>
            </form>
        </div>
        <div class="flex flex-col border rounded-lg p-2 w-3/12 mobile:w-full">
            <div class="text-xs text-slate-500">Cabang</div>
            <select class="w-full cursor-pointer h-8 text-xs text-slate-600 outline-0" onchange="addFilter({branch_id: this.value})">
                <option value="">Semua Cabang</option>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($branch->id); ?>" <?php echo e($request->branch_id == $branch->id ? "selected='selected'" : ""); ?>><?php echo e($branch->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="flex flex-col border rounded-lg p-2 w-3/12 mobile:w-full">
            <div class="text-xs text-slate-500">Rentang Tanggal</div>
            <div class="flex items-center">
                <input type="text" id="dateRangePicker" class="h-8 outline-0 text-xs text-slate-600 w-full">
                <ion-icon name="chevron-down-outline"></ion-icon>
            </div>
        </div>
        <button class="h-12 w-12 flex items-center justify-center rounded-lg bg-green-500 text-white" onclick="addFilter({download: 1})">
            <ion-icon name="download-outline" class="text-2xl"></ion-icon>
        </button>
    </div>

    <div class="bg-white rounded-lg p-4">
        <!-- Outer scroll container -->
        <div class="overflow-x-auto mt-2">
            <!-- Inner scrollable width wrapper -->
            <div class="w-max min-w-full mt-0 space-y-1">
                <!-- Header -->
                <div class="flex bg-slate-100 text-slate-600 text-sm font-semibold px-4 py-2 rounded min-w-full">
                    <div class="w-32">
                        <ion-icon name="calendar-outline"></ion-icon>
                    </div>
                    <div class="w-48">No. Pembelian</div>
                    <div class="w-36">Cabang</div>
                    <div class="w-36">Staff</div>
                    <div class="w-36">Supplier</div>
                    <div class="w-40">Produk</div>
                    <div class="w-24">Harga</div>
                    <div class="w-24">Qty</div>
                    <div class="w-28">Subtotal</div>
                    <div class="w-28">Total Qty</div>
                    <div class="w-32">Total Harga</div>
                    <div class="w-36">Penerima</div>
                    <div class="w-36"></div>
                </div>

                <!-- Rows -->
                <?php $__currentLoopData = $purchasings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex bg-white text-slate-700 text-sm px-4 py-2 rounded shadow-sm min-w-full">
                            <?php if($i === 0): ?>
                                <div class="w-32">
                                    <div><?php echo e(Carbon::parse($purchase->created_at)->isoFormat('DD MMMM YYYY')); ?></div>
                                    <div class="text-xs text-slate-500"><?php echo e(Carbon::parse($purchase->created_at)->isoFormat('HH:mm')); ?></div>
                                </div>
                                <div class="w-48"><?php echo e(@$purchase->label); ?></div>
                                <div class="w-36"><?php echo e(@$purchase->branch->name); ?></div>
                                <div class="w-36"><?php echo e(@$purchase->creator->name); ?></div>
                                <div class="w-36"><?php echo e(@$purchase->supplier->name); ?></div>
                            <?php else: ?>
                                <div class="w-32"></div>
                                <div class="w-48"></div>
                                <div class="w-36"></div>
                                <div class="w-36"></div>
                                <div class="w-36"></div>
                            <?php endif; ?>

                            <div class="w-40"><?php echo e($item->product->name); ?></div>
                            <div class="w-24"><?php echo e(currency_encode($item->price)); ?></div>
                            <div class="w-24"><?php echo e($item->quantity); ?></div>
                            <div class="w-28"><?php echo e(currency_encode($item->total_price)); ?></div>

                            <?php if($i === 0): ?>
                                <div class="w-28"><?php echo e(@$purchase->total_quantity); ?></div>
                                <div class="w-32"><?php echo e(currency_encode(@$purchase->total_price)); ?></div>
                                <div class="w-36"><?php echo e(@$purchase->receiver->name); ?></div>
                                <div class="w-32">
                                    <div><?php echo e(Carbon::parse($purchase->received_at)->isoFormat('DD MMMM YYYY')); ?></div>
                                    <div class="text-xs text-slate-500"><?php echo e(Carbon::parse($purchase->received_at)->isoFormat('HH:mm')); ?></div>
                                </div>
                            <?php else: ?>
                                <div class="w-28"></div>
                                <div class="w-32"></div>
                                <div class="w-36"></div>
                                <div class="w-36"></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php if($purchasings->hasMorePages()): ?>
        <div class="bg-white rounded-lg p-4 shadow shadow-slate-200">
            <?php echo e($purchasings->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/dayjs@1/dayjs.min.js"></script>

<script>
    const startDate = select("#startDate").value;
    const endDate = select("#endDate").value;

    flatpickr("#dateRangePicker", {
        mode: "range",
        dateFormat: "Y-m-d",
        defaultDate: [startDate, endDate],
        locale: {
            rangeSeparator: " ke ",
        },
        onChange: selectedDates => {
            if (selectedDates.length === 2) {
                const [start, end] = selectedDates;
                addFilter({
                    start_date: dayjs(start).format('YYYY-MM-DD'),
                    end_date: dayjs(end).format('YYYY-MM-DD'),
                });
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/report/purchasing.blade.php ENDPATH**/ ?>