<?php $__env->startSection('title', "Paling Laku"); ?>
    
<?php $__env->startSection('content'); ?>
<input type="hidden" id="chartOptions" value="<?php echo e(json_encode($chartOptions)); ?>">
<div class="p-8 flex flex-col gap-8">
    <div class="flex items-center gap-4">
        <div class="flex grow">
            <a href="<?php echo e(url()->previous()); ?>" class="flex items-center gap-3">
                <ion-icon name="arrow-back-outline"></ion-icon>
                <div class="text-xs text-slate-500">Kembali</div>
            </a>
        </div>
        <select name="branch_id" id="branch_id" class="text-xs text-slate-600 font-medium border rounded-lg p-3 px-3" onchange="addFilter('branch_id', this.value)">
            <option value="">Semua Cabang</option>
            <?php $__currentLoopData = $me->branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($branch->id); ?>" <?php echo e($branchID == $branch->id ? "selected='selected'" : ""); ?>><?php echo e($branch->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="date_range" id="date_range" class="text-xs text-slate-600 font-medium border rounded-lg p-3 px-3" onchange="addFilter('date_range', this.value)">
            <?php $__currentLoopData = config('report_date_ranges'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e($request->date_range == $key ? "selected='selected'" : ""); ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-8 flex gap-8">
        <div class="w-5/12">
            <div id="Chart" class="w-full aspect-square"></div>
        </div>
        <div class="flex flex-col gap-4 grow">
            <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center gap-2">
                    <div class="flex flex-col gap-1 grow">
                        <div class="text-sm text-slate-600"><?php echo e($item['product_name']); ?></div>
                        <div class="text-xs text-red-500"><?php echo e(currency_encode($item['total_sales'])); ?></div>
                    </div>
                    <div class="text-xs text-slate-500">
                        <?php echo e($item['total_qty']); ?> pieces
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.6.0/dist/echarts.min.js" integrity="sha256-v0oiNSTkC3fDBL7GfhIiz1UfFIgM9Cxp3ARlWOEcB7E=" crossorigin="anonymous"></script>
<script>
    const chartOptions = JSON.parse(select("#chartOptions").value);
    const paymentSummaryChart = echarts.init(
        select("#Chart")
    );

    paymentSummaryChart.setOption(chartOptions);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/report/top_selling.blade.php ENDPATH**/ ?>