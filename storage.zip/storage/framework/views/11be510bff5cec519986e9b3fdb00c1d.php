<?php
    use Carbon\Carbon;

    $start = Carbon::parse($startDate)->isoFormat('DD MMMM YYYY');
    $end = Carbon::parse($endDate)->isoFormat('DD MMMM YYYY');
?>
<table>
    <thead>
        <tr>
            <th colspan="6" style="text-align: center;font-size: 24px;font-weight: medium;">PERGERAKAN STOK</th>
        </tr>
        <tr>
            <th colspan="6" style="text-align: center;font-size: 12px;">Periode : <?php echo e($start); ?> - <?php echo e($end); ?></th>
        </tr>
        <tr>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Produk</th>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Cabang</th>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Stok Aktual</th>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Masuk</th>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Keluar</th>
            <th style="font-weight: bold;background-color: #eeeeee;color: #333;">Opname</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->branch->name); ?></td>
                <td><?php echo e($product->quantity); ?></td>
                <td><?php echo e($product->movements['inbound']); ?></td>
                <td><?php echo e($product->movements['outbound']); ?></td>
                <td><?php echo e($product->movements['opname']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/excel/movement.blade.php ENDPATH**/ ?>