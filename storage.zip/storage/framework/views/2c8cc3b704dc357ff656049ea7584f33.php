<?php if($message != ""): ?>
    <div class="bg-green p-4 rounded-lg bg-green-500 text-white text-sm mt-6">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<div class="bg-white rounded-lg p-8 shadow shadow-slate-200 mt-2">
    <div class="flex items-center gap-4">
        <a href="<?php echo e(route('customer', ['tab' => "customer_type"])); ?>">
            <ion-icon name="arrow-back-outline" class="text-xl text-slate-700"></ion-icon>
        </a>
        <div class="text-lg text-slate-700 font-medium flex grow"><?php echo e($type->name); ?></div>
        <div class="text-xs text-slate-500">
            Jumlah Pelanggan : <?php echo e($type->customers->count()); ?>

        </div>
    </div>
    <div class="min-w-full overflow-hidden overflow-x-auto p-5">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="text-sm text-slate-700 bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">Nama</th>
                    <th scope="col" class="px-6 py-3 text-left">Email</th>
                    <th scope="col" class="px-6 py-3 text-left">No. Telepon</th>
                    <th scope="col" class="px-6 py-3 text-left"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $type->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 text-sm text-slate-700"><?php echo e($customer->name); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-700"><?php echo e($customer->email); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-700"><?php echo e($customer->phone); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-700 flex items-center gap-4">
                            <a href="<?php echo e(route('customer.type.remove', [$type->id, $customer->id])); ?>" class="p-2 px-3 rounded-lg flex items-center bg-red-500 text-white" onclick="RemoveCustomerFromType(event, '<?php echo e($customer); ?>', '<?php echo e($type); ?>')">
                                <ion-icon name="close-outline" class="text-lg"></ion-icon>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/customer/customer_type_detail.blade.php ENDPATH**/ ?>