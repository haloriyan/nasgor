<?php $__env->startSection('title', "Pembelian"); ?>

<?php
    use Carbon\Carbon;
    Carbon::setLocale('id');
?>
    
<?php $__env->startSection('content'); ?>
<div class="p-8">
    <div class="flex items-center w-full p-2 bg-white rounded-lg">
        <a href="?tab=draft" class="p-3 px-6 rounded-lg text-sm <?php echo e(($tab == '' || $tab == 'draft') ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
            Butuh Diproses
        </a>
        <a href="?tab=received" class="p-3 px-6 rounded-lg text-sm <?php echo e($tab == 'received' ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
            Telah Diproses
        </a>
        <div class="flex grow"></div>
        <button class="p-3 px-4 rounded-lg bg-primary text-white text-xs font-medium flex items-center gap-2" onclick="toggleHidden('#CreatePurchasing')">
            <ion-icon name="add-outline" class="text-xl"></ion-icon>
            Tambah
        </button>
    </div>

    <?php if($message != ""): ?>
        <div class="bg-green-500 rounded-lg p-4 text-white text-sm">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <div class="flex flex-col gap-4 bg-white p-8 rounded-lg shadow shadow-slate-200 mt-8">
        <div class="min-w-full overflow-hidden overflow-x-auto p-5">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="text-sm text-slate-700 bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left">No. Pembelian</th>
                        <th scope="col" class="px-6 py-3 text-left">
                            <ion-icon name="calendar-outline"></ion-icon>
                        </th>
                        <th scope="col" class="px-6 py-3 text-left">Supplier</th>
                        <th scope="col" class="px-6 py-3 text-left">Jumlah</th>
                        <th scope="col" class="px-6 py-3 text-left">Nominal</th>
                        <th scope="col" class="px-6 py-3 text-left"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $purchasings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <a href="<?php echo e(route('purchasing.detail', $purchase->id)); ?>" class="text-primary font-medium">
                                    <?php echo e($purchase->label); ?>

                                </a>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <?php echo e(Carbon::parse($purchase->created_at)->isoFormat('DD MMMM YYYY')); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <?php echo e($purchase->supplier->name); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <?php echo e($purchase->total_quantity); ?> item(s)
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <?php echo e(currency_encode($purchase->total_price)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>
<?php echo $__env->make('user.purchasing.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    // 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/purchasing/index.blade.php ENDPATH**/ ?>