<div class="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-75 flex items-center justify-center hidden z-30" id="AddCustomer">
    <form action="{{ route('customer.store') }}" method="POST" enctype="multipart/form-data" class="bg-white shadow-lg rounded-lg p-10 w-4/12 mobile:w-10/12 flex flex-col gap-4 mt-4">
        @csrf
        <input type="hidden" name="id" id="id">
        <div class="flex items-center gap-4 mb-2">
            <h3 class="text-lg text-slate-700 font-medium flex grow" id="title">Tambah Pelanggan</h3>
            <ion-icon name="close-outline" class="cursor-pointer text-3xl" onclick="Cancel('#AddCustomer')"></ion-icon>
        </div>

        <div id="CustomerTypeSelector"></div>

        <div class="group border focus-within:border-primary rounded-lg p-2 relative">
            <label class="text-slate-500 group-focus-within:text-primary text-xs absolute top-2 left-2">Nama</label>
            <input type="text" name="name" id="name" class="w-full h-10 mt-2 outline-none bg-transparent text-sm text-slate-700" required />
        </div>
        <div class="group border focus-within:border-primary rounded-lg p-2 relative">
            <label class="text-slate-500 group-focus-within:text-primary text-xs absolute top-2 left-2">Email</label>
            <input type="email" name="email" id="email" class="w-full h-10 mt-2 outline-none bg-transparent text-sm text-slate-700" />
        </div>
        <div class="group border focus-within:border-primary rounded-lg p-2 relative">
            <label class="text-slate-500 group-focus-within:text-primary text-xs absolute top-2 left-2">No. Telepon</label>
            <input type="text" name="phone" id="phone" class="w-full h-10 mt-2 outline-none bg-transparent text-sm text-slate-700" />
        </div>
        
        <div class="flex items-center justify-end gap-4 mt-4">
            <button class="p-3 px-6 rounded-lg text-sm bg-slate-200 text-slate-700" type="button" onclick="Cancel('#AddCustomer')">Batal</button>
            <button class="p-3 px-6 rounded-lg text-sm bg-green-500 text-white font-medium">Submit</button>
        </div>
    </form>
</div>