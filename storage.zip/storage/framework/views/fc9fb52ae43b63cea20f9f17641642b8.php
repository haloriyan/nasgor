<?php $__env->startSection('title', "Supplier"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="p-8 flex flex-col gap-4">
    <div class="bg-white rounded-lg shadow shadow-slate-200 p-2 flex items-center gap-4">
        <form class="flex items-center gap-2 grow">
            <button class="flex items-center px-4">
                <ion-icon name="search-outline"></ion-icon>
            </button>
            <input type="text" name="q" class="w-full h-12 px-2 outline-0 text-sm text-slate-600" placeholder="Cari supplier">
        </form>
        <button class="bg-green-500 text-sm text-white font-medium p-3 px-4 rounded-lg flex items-center gap-2" onclick="toggleHidden('#AddSupplier')">
            <ion-icon name="add-outline" class="mobile:text-xl"></ion-icon>
            <div class="mobile:hidden">Tambah Supplier</div>
        </button>
    </div>
</div>

<?php if($message != ""): ?>
    <div class="bg-green-500 p-2 rounded-lg text-white text-sm m-8 mt-0">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<div class="grid grid-cols-3 mobile:grid-cols-1 gap-8 p-8 mobile:pt-0">
    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col gap-4 bg-white rounded-lg shadow shadow-slate-200 p-8">
            <div class="flex items-start gap-4">
                <?php if($supplier->photo == null): ?>
                    <div class="h-24 w-24 rounded-lg bg-slate-200 flex items-center justify-center">
                        <ion-icon name="image-outline" class="text-xl"></ion-icon>
                    </div>
                <?php else: ?>
                    <img 
                        src="<?php echo e(asset('storage/supplier_photos/' . $supplier->photo)); ?>" 
                        alt="<?php echo e($supplier->name); ?>" 
                        class="h-24 aspect-square rounded-lg object-cover"
                    >
                <?php endif; ?>
                <div class="flex flex-col gap-2 grow">
                    <h4 class="text-slate-700 fext-sm font-medium"><?php echo e($supplier->name); ?></h4>
                    <div class="flex items-center gap-4">
                        <button class="h-8 w-8 rounded-lg flex items-center justify-center text-white bg-green-500" onclick="EditSupplier('<?php echo e($supplier); ?>')">
                            <ion-icon name="create-outline" class="text-lg"></ion-icon>
                        </button>
                        <button class="h-8 w-8 rounded-lg flex items-center justify-center text-white bg-red-500" onclick="DeleteSupplier('<?php echo e($supplier); ?>')">
                            <ion-icon name="trash-outline" class="text-lg"></ion-icon>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="flex items-center gap-2 text-slate-500 mt-2">
                <ion-icon name="person-outline"></ion-icon>
                <div class="text-xs"><?php echo e($supplier->pic_name); ?></div>
            </div>
            <div class="flex items-center gap-2 text-slate-500">
                <ion-icon name="mail-outline"></ion-icon>
                <div class="text-xs"><?php echo e($supplier->email); ?></div>
            </div>
            <div class="flex items-center gap-2 text-slate-500">
                <ion-icon name="call-outline"></ion-icon>
                <div class="text-xs"><?php echo e($supplier->phone); ?></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>
<?php echo $__env->make('user.supplier.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('user.supplier.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    let isEditing = false;
    const EditSupplier = data => {
        isEditing = true;
        data = JSON.parse(data);
        let imagePreview = select("#AddSupplier #imagePreview");
        select("#AddSupplier #title").innerHTML = "Edit Supplier";
        select("#AddSupplier #id").value = data.id;
        select("#AddSupplier #name").value = data.name;
        select("#AddSupplier #pic_name").value = data.pic_name;
        select("#AddSupplier #email").value = data.email;
        select("#AddSupplier #phone").value = data.phone;
        select("#AddSupplier #address").value = data.address;

        if (data.photo !== null) {
            let filename = encodeURIComponent(data.photo); // encodes spaces, &, #, etc.
            let source = `/storage/supplier_photos/${filename}`;
            applyImageToDiv(imagePreview, source);
        }

        toggleHidden("#AddSupplier");
    }
    const DeleteSupplier = data => {
        data = JSON.parse(data);
        select("#DeleteSupplier #id").value = data.id;
        select("#DeleteSupplier #name").innerHTML = data.name;
        toggleHidden("#DeleteSupplier");
    }
    const Cancel = (target) => {
        toggleHidden(target);
        if (isEditing) {
            select("#AddSupplier #title").innerHTML = "Tambah Supplier";
            isEditing = false;
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/supplier/index.blade.php ENDPATH**/ ?>