<?php $__env->startSection('title', $code); ?>
    
<?php $__env->startSection('ModalArea'); ?>
<div class="fixed top-0 left-0 right-0 bottom-0 bg-white p-8 flex items-center justify-center z-30">
    <h1 class="text-[240px] mobile:text-[180px] font-bold text-slate-100 tracking-widest"><?php echo e($code); ?></h1>
</div>
<div class="fixed top-0 left-0 right-0 bottom-0 p-8 flex flex-col gap-4 items-center justify-center z-40">
    <h1 class="text-center text-5xl mobile:text-2xl font-bold text-slate-700"><?php echo e($error['title']); ?></h1>
    <div class="text-center mobile:text-sm text-slate-600"><?php echo e($error['description']); ?></div>
    <div class="h-4"></div>
    <a href="<?php echo e(route('dashboard')); ?>" class="bg-primary p-3 px-6 rounded-lg text-white text-sm font-medium">
        Kembali ke Dashboard
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/error.blade.php ENDPATH**/ ?>