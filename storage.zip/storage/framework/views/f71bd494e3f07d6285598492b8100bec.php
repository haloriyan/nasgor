<?php if($message != ""): ?>
    <div class="bg-green-500 text-sm text-white rounded-lg p-4">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<table class="bg-white rounded-lg">
    <thead>
        <tr class="border-b">
            <td class="p-4 px-6 text-sm text-slate-700 font-medium">Staf</td>
            <td class="p-4 px-6 text-sm text-slate-700 font-medium">Peran</td>
            <td></td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $accesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="p-4 px-6 text-sm text-slate-500">
                    <?php echo e($access->user->name); ?>

                </td>
                <td class="p-4 px-6 text-sm text-slate-500">
                    <?php echo e($access->role->name); ?>

                </td>
                <td class="p-4 px-6">
                    <a href="<?php echo e(route('accessRole.removeAccess', $access->id)); ?>" class="bg-red-500 text-white p-2 px-3 rounded-lg">
                        <ion-icon name="close-outline"></ion-icon>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/branch/access/index.blade.php ENDPATH**/ ?>