<?php $__env->startSection('title', $sales->invoice_number . " - " . $sales->branch->name); ?>

<?php
    use Carbon\Carbon;
    $branch = $sales->branch;
    $customer = $sales->customer;
?>
    
<?php $__env->startSection('content'); ?>
<?php if($message != ""): ?>
    <div class="bg-green-500 text-white text-sm p-4 rounded-lg font-medium mt-8 mobile:m-8">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<div class="bg-white rounded-lg mt-4 mobile:m-4 border">
    <div class="flex items-center gap-4 p-8 py-6 border-b">
        <div class="flex flex-col gap-1 grow">
            <h1 class="text-2xl text-slate-700 font-medium">Invoice</h1>
            <div class="text-xs text-slate-500">
                No. Invoice : <?php echo e($sales->invoice_number); ?>

            </div>
        </div>
        <?php if($sales->branch->icon != null): ?>
            <img 
                src="<?php echo e(asset('storage/branch_icons/' . $branch->icon)); ?>" 
                alt="<?php echo e($branch->name); ?>"
                class="w-14 h-14 rounded-lg"
            >
        <?php endif; ?>
    </div>
    <div class="grid grid-cols-2 gap-6 p-8">
        <div class="flex flex-col gap-1">
            <div class="text-xs text-slate-400">Diterbitkan oleh</div>
            <div class="text-slate-700 font-medium mt-1">
                <?php echo e(env('APP_NAME')); ?> - <?php echo e($branch->name); ?>

            </div>
            <div class="text-xs text-slate-500"><?php echo e($branch->address); ?></div>
        </div>
        <div class="flex flex-col gap-1">
            <div class="text-xs text-slate-400">Ditagihkan kepada</div>
            <?php if($customer == null): ?>
                <div class="text-slate-600 text-lg">-</div>
            <?php else: ?>
                <div class="text-slate-700 font-medium mt-1">
                    <?php echo e($customer->name); ?>

                </div>
                <?php if($customer->phone != null): ?>
                    <div class="text-xs text-slate-500"><?php echo e($customer->phone); ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="grid grid-cols-2 gap-6 p-8 pt-0">
        <div class="flex flex-col gap-1"></div>
        <div class="flex flex-col gap-1">
            <div class="text-xs text-slate-400">Tanggal</div>
            <div class="text-slate-700 font-medium mt-1">
                <?php echo e(Carbon::parse($sales->created_at)->isoFormat('DD MMMM YYYY - HH:mm')); ?>

            </div>
        </div>
    </div>
    <div class="p-8 border-t">
        <div class="text-xs text-slate-400">Detail</div>
        <div class="min-w-full overflow-hidden overflow-x-auto mt-2">
            <table class="table min-w-full divide-y mt-4">
                <thead>
                    <tr class="border-b">
                        <td class="p-2 px-0 text-sm text-slate-700 font-medium">Produk</td>
                        <td class="p-2 text-sm text-slate-700 font-medium">Harga</td>
                        <td class="p-2 text-sm text-slate-700 font-medium">Qty</td>
                        <td class="p-2 text-sm text-slate-700 font-medium">Total</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sales->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-4 text-sm text-slate-700">
                                <div class="flex items-start gap-4">
                                    <?php if($item->product->images->count() == 0): ?>
                                        <div class="w-16 h-16 rounded-lg flex items-center justify-center bg-slate-100">
                                            <ion-icon name="image-outline" class="text-xl"></ion-icon>
                                        </div>
                                    <?php else: ?>
                                        <img 
                                            src="<?php echo e(asset('storage/product_images/' . $item->product->images[0]->filename)); ?>" 
                                            alt="<?php echo e($item->id); ?>"
                                            class="w-16 h-16 rounded-lg object-cover mobile:hidden"
                                        >
                                    <?php endif; ?>
                                    
                                    <div class="flex flex-col gap-2">
                                        <div class="text-sm text-slate-600 font-medium"><?php echo e($item->product->name); ?></div>
                                        <div class="flex flex-col gap-1">
                                            <?php $__currentLoopData = $item->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-xs text-slate-500">+ <?php echo e($add->quantity); ?> <?php echo e($add->addon->name); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="p-2 py-4 text-sm text-slate-700">
                                <div class="text-sm text-slate-600 font-medium">
                                    <?php echo e(currency_encode($item->total_price)); ?>

                                </div>
                                <?php if($item->additional_price > 0): ?>
                                    <div class="text-xs text-slate-500 mt-2">
                                        + <?php echo e(currency_encode($item->additional_price)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="p-2 py-4 text-sm text-slate-700">
                                <?php echo e($item->quantity); ?>

                            </td>
                            <td class="p-2 py-4 text-sm text-slate-700 font-medium">
                                <?php echo e(currency_encode($item->grand_total)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="py-4 text-sm text-slate-700 font-medium" colspan="2">Total</td>
                        <td class="py-4 text-sm text-slate-700 font-medium"><?php echo e($sales->total_quantity); ?></td>
                        <td class="py-4 text-sm text-slate-700 font-medium"><?php echo e(currency_encode($sales->total_price)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if($sales->review == null && $sales->customer_id != null): ?>
    <div class="bg-white rounded-lg mt-4 mobile:m-4 border">
        <form action="<?php echo e(route('invoice.review', $sales->invoice_number)); ?>" method="POST" class="flex flex-col gap-4 p-8  border-b" id="WriteReview">
            <?php echo csrf_field(); ?>
            <div class="flex items-center gap-4">
                <h2 class="text-xl text-slate-700 font-medium flex grow">Tulis Ulasan</h2>
                <input type="text" class="w-8 h-12 opacity-0 cursor-default" name="rating" id="rating" required>
                <div class="flex flex-col items-end gap-1">
                    <div id="star-container" class="flex gap-2 justify-center text-xl cursor-pointer">
                        <span class="star text-gray-400" onclick="handleStarClick(1)">&#9733;</span>
                        <span class="star text-gray-400" onclick="handleStarClick(2)">&#9733;</span>
                        <span class="star text-gray-400" onclick="handleStarClick(3)">&#9733;</span>
                        <span class="star text-gray-400" onclick="handleStarClick(4)">&#9733;</span>
                        <span class="star text-gray-400" onclick="handleStarClick(5)">&#9733;</span>
                    </div>
                    <div id="StarLabel" class="text-xs text-slate-500"></div>
                </div>
            </div>
            <textarea name="body" id="body" rows="6" class="text-sm text-slate-500 outline-0" placeholder="Tulis pendapat atau keluhanmu mengenai produk dan pelayanan Kami"></textarea>
            <div class="flex justify-end">
                <button class="p-3 px-4 rounded-lg bg-green-500 text-sm text-white font-medium">
                    Submit
                </button>
            </div>
        </form>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    const handleStarClick = (rating) => {
        const stars = document.querySelectorAll(".star");
        const starLabels = [
            "Saya Tidak Suka",
            "Kurang Baik",
            "Bisa Lebih Baik",
            "Saya Menyukainya",
            "Produk ini Fantastis!"
        ];

        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add("text-yellow-400");
                star.classList.remove("text-gray-400");
            } else {
                star.classList.add("text-gray-400");
                star.classList.remove("text-yellow-400");
            }
        });

        select("#WriteReview #StarLabel").innerHTML = starLabels[rating - 1];
        select("#WriteReview #rating").value = rating;

        console.log(`Selected rating: ${rating}`);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.invoice', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/invoice.blade.php ENDPATH**/ ?>