<?php $__env->startSection('title', "Login"); ?>
    
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('login')); ?>" method="POST" class="flex flex-col gap-2">
    <?php echo csrf_field(); ?>
    <h1 class="text-xl text-slate-700 font-medium mb-4">Login</h1>
    <label for="email" class="text-slate-500 text-xs">Username</label>
    <input type="text" name="email" id="email" class="w-full h-14 rounded-lg bg-slate-100 text-sm text-slate-700 px-4 outline-0" required value="">
    <label for="email" class="text-slate-500 text-xs mt-2">Password</label>
    <input type="password" name="password" id="password" class="w-full h-14 rounded-lg bg-slate-100 text-sm text-slate-700 px-4 outline-0" required value="">

    <?php if($errors->count() > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-red-100 text-red-500 text-sm p-4 rounded-lg mt-4">
                <?php echo e($err); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if($message != ""): ?>
        <div class="bg-green-100 text-green-500 text-sm p-4 rounded-lg mt-4">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    <button class="mt-4 rounded-lg bg-primary text-white text-sm font-medium w-full h-12">Login</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/login.blade.php ENDPATH**/ ?>