<div class="bg-white p-8 rounded-lg shadow">
    <div class="text-xs text-slate-500">Yang diminta cabang ini dari cabang lain</div>

    <div class="min-w-full overflow-hidden overflow-x-auto mt-6">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="text-sm text-slate-700 bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">Produk</th>
                    <th scope="col" class="px-6 py-3 text-left">Cabang yang Diminta</th>
                    <th scope="col" class="px-6 py-3 text-left">Jumlah</th>
                    <th scope="col" class="px-6 py-3 text-left"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $myRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <div class="flex items-center gap-2">
                                <?php if($item->product->images->count() == 0): ?>
                                    <div class="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center">
                                        <ion-icon name="image-outline" class="text-xl"></ion-icon>
                                    </div>
                                <?php else: ?>
                                    <img 
                                        src="<?php echo e(asset('storage/product_images/' . $item->product->images[0]->filename)); ?>" alt="<?php echo e($item->id); ?>"
                                        class="w-16 h-16 bg-slate-100 rounded-lg object-cover"
                                    >
                                <?php endif; ?>
                                <div class="text-sm text-slate-600"><?php echo e($item->product->name); ?></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($item->provider_branch->name); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($item->quantity); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <div class="flex items-center gap-3">
                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/stock_request/out.blade.php ENDPATH**/ ?>