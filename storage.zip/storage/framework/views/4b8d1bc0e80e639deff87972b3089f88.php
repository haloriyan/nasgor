<table>
    <thead>
        <tr>
            <th colspan="10" style="text-align: center; font-size: 24px; font-weight: medium;">SALES REPORT</th>
        </tr>
        <tr>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Tanggal</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">No. Invoice</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Cabang</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Staff</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Produk</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Harga</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Qty</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Subtotal</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Total Qty</th>
            <th style="font-weight: bold; background-color: #eeeeee; color: #333;">Total Harga</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($i == 0): ?>
                        <td><?php echo e($sale->created_at); ?></td>
                        <td><?php echo e($sale->invoice_number); ?></td>
                        <td><?php echo e($sale->branch->name); ?></td>
                        <td><?php echo e($sale->user->name); ?></td>
                    <?php else: ?>
                        <td colspan="4"></td>
                    <?php endif; ?>

                    <td><?php echo e(@$item->product->name); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e($item->total_price); ?></td>

                    <?php if($i == 0): ?>
                        <td><?php echo e($sale->total_quantity); ?></td>
                        <td><?php echo e($sale->total_price); ?></td>
                    <?php else: ?>
                        <td colspan="2"></td>
                    <?php endif; ?>
                </tr>

                
                <?php $__currentLoopData = $item->addons ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="4"></td>
                        <td>↳ <?php echo e($addon->addon->name); ?></td>
                        <td><?php echo e($addon->price); ?></td>
                        <td><?php echo e($addon->quantity); ?></td>
                        <td><?php echo e($addon->total_price); ?></td>
                        <td colspan="2"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/excel/sales.blade.php ENDPATH**/ ?>