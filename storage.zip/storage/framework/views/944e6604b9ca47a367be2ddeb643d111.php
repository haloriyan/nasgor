<?php $__env->startSection('title', "Detail Penjualan"); ?>

<?php
    use Carbon\Carbon;
?>
    
<?php $__env->startSection('content'); ?>
<div class="flex flex-col gap-8 p-8">
    <div class="flex items-center gap-4 bg-white rounded-lg shadow shadow-slate-200 p-8">
        <a href="<?php echo e(route('sales')); ?>" class="flex items-center">
            <ion-icon name="arrow-back-outline" class="text-xl text-slate-600"></ion-icon>
        </a>
        <div class="flex flex-col gap-1 grow">
            <h3 class="text-lg text-slate-700 font-medium"><?php echo e($sales->invoice_number); ?></h3>
        </div>
        <?php if($sales->status == "DRAFT"): ?>
            <a href="<?php echo e(route('sales.proceed', $sales->id)); ?>" class="bg-green-500 text-white text-sm p-3 px-6 rounded-lg font-medium">
                Proses
            </a>
        <?php else: ?>
            <div class="flex items-center gap-2">
                <div class="text-xs p-2 px-3 rounded-full <?php echo e($sales->payment_status == "UNPAID" ? 'bg-slate-200 text-slate-500' : 'bg-white text-slate-700'); ?>">Belum Bayar</div>
                <a href="<?php echo e(route('sales.detail.togglePaymentStatus', $sales->id)); ?>" class="p-1 rounded-full <?php echo e($sales->payment_status == "PAID" ? 'bg-green-500' : 'bg-slate-200'); ?>">
                    <div class="h-6 w-6 bg-white rounded-full <?php echo e($sales->payment_status == "PAID" ? 'ms-6' : 'me-6'); ?>" id="SwitchDot"></div>
                </a>
                <div class="text-xs p-2 px-3 rounded-full <?php echo e($sales->payment_status == "PAID" ? 'bg-green-500 text-white' : 'text-slate-700'); ?>">Lunas</div>
            </div>
        <?php endif; ?>
    </div>

    <?php if($message != ""): ?>
        <div class="bg-green-500 text-white text-sm rounded-lg p-4">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-3 mobile:grid-cols-1 gap-8">
        <?php if($sales->customer != null): ?>
            <div class="bg-white rounded-lg border">
                <div class="h-20 px-8 flex items-center gap-4 border-b">
                    <ion-icon name="person-outline" class="text-xl"></ion-icon>
                    <div class="flex grow">Pelanggan</div>
                    <?php if($sales->status == "DRAFT"): ?>
                        <button class="p-2 px-4 rounded-lg bg-primary text-white text-xs font-medium flex items-center" onclick="toggleHidden('#EditCustomer')">
                            Ganti
                        </button>
                    <?php endif; ?>
                </div>
                <div class="p-8">
                    <div class="text-slate-700 font-medium flex grow mt-1"><?php echo e(@$sales->customer->name); ?></div>
                    <div class="flex items-center gap-2 mt-2">
                        <?php $__currentLoopData = @$sales->customer->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-1 px-3 rounded-lg text-xs text-white font-medium" style="background-color: <?php echo e($type->color); ?>25;color: <?php echo e($type->color); ?>">
                                <?php echo e($type->name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="flex items-center gap-4 text-slate-500 mt-6">
                        <ion-icon name="call-outline" class="text-lg"></ion-icon>
                        <div class="text-sm"><?php echo e(@$sales->customer->phone); ?></div>
                    </div>
                    <div class="flex items-center gap-4 text-slate-500 mt-2">
                        <ion-icon name="mail-outline" class="text-lg"></ion-icon>
                        <div class="text-sm"><?php echo e(@$sales->customer->email); ?></div>
                    </div>

                    <?php if($sales->review != null): ?>
                        <div class="border-t pt-4 mt-4">
                            <div class="flex items-center gap-2">
                                <div class="text-xs text-slate-400">Penilaian :</div>
                                <div class="flex items-center justify-end grow gap-2">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <ion-icon name="star" class="<?php echo e($sales->review->rating < $i ? 'text-slate-400' : 'text-yellow-500'); ?>"></ion-icon>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="text-sm text-slate-600 mt-4 border rounded-lg p-4"><?php echo e($sales->review->body); ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if($sales->review == null && $sales->payment_status == "PAID" && @$sales->customer->phone != null): ?>
                        <div class="border-t pt-4 mt-4 flex justify-end">
                            <a href="<?php echo e($waLink); ?>" class="bg-green-500 p-2 px-4 rounded-full text-white text-sm font-medium" target="_blank">
                                Kirim Invoice
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="bg-white rounded-lg border">
            <div class="h-20 px-8 flex items-center gap-4 border-b">
                <ion-icon name="create-outline" class="text-xl"></ion-icon>
                <div class="flex grow">Catatan</div>
                <?php if($sales->status == "DRAFT"): ?>
                    <button class="p-2 px-4 rounded-lg bg-primary text-white text-xs font-medium flex items-center" onclick="toggleHidden('#EditNotes')">
                        Edit
                    </button>
                <?php endif; ?>
            </div>
            <div class="p-8">
                <?php echo e($sales->notes); ?>

            </div>
        </div>
        <div class="bg-white rounded-lg border">
            <div class="h-20 px-8 flex items-center gap-4 border-b">
                <ion-icon name="sync-outline" class="text-xl"></ion-icon>
                <div class="flex grow">Log</div>
            </div>
            <div class="p-8 flex flex-col gap-2">
                <div class="text-xs text-slate-500 mb-1">Dibuat</div>
                <div class="flex items-center gap-2 text-slate-700 text-sm">
                    <ion-icon name="person-outline"></ion-icon>
                    <div class="text-xs"><?php echo e($sales->user->name); ?></div>
                </div>
                <div class="flex items-center gap-2 text-slate-700 text-sm">
                    <ion-icon name="time-outline"></ion-icon>
                    <div class="text-xs"><?php echo e(Carbon::parse($sales->created_at)->isoFormat('DD MMMM YYYY, HH:mm:ss')); ?></div>
                </div>
                <div class="text-xs text-slate-500 mt-4">Diperbarui</div>
                <div class="flex items-center gap-2 text-slate-700 text-sm">
                    <ion-icon name="time-outline"></ion-icon>
                    <div class="text-xs"><?php echo e(Carbon::parse($sales->updated_at)->isoFormat('DD MMMM YYYY, HH:mm:ss')); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="flex flex-col bg-white rounded-lg border">
        <div class="h-20 px-8 flex items-center gap-4 border-b">
            <ion-icon name="cube-outline" class="text-xl"></ion-icon>
            <div class="flex grow">Produk</div>
            <?php if($sales->status == "DRAFT"): ?>
                <button class="p-2 px-4 rounded-lg bg-primary text-white text-xs font-medium flex items-center" onclick="toggleHidden('#AddProduct')">
                    <ion-icon name="add-outline" class="text-lg"></ion-icon>
                </button>
            <?php endif; ?>
        </div>
        <div class="min-w-full overflow-hidden overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="text-sm text-slate-700 bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left">Produk</th>
                        <th scope="col" class="px-6 py-3 text-left">Qty</th>
                        <th scope="col" class="px-6 py-3 text-left">Harga</th>
                        <th scope="col" class="px-6 py-3 text-left">Total</th>
                        <th scope="col" class="px-6 py-3 text-left"></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $sales->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <div class="flex items-start gap-4">
                                    <?php if($item->product->images->count() > 0): ?>
                                        <img 
                                            src="<?php echo e(asset('storage/product_images/' . @$item->product->images[0]->filename)); ?>" 
                                            alt="<?php echo e($item->id); ?>"
                                            class="w-16 h-16 rounded-lg object-cover"
                                        >
                                    <?php else: ?> 
                                        <div class="flex items-center justify-center rounded-lg w-16 h-16 bg-slate-100">
                                            <ion-icon name="image-outline" class="text-lg"></ion-icon>
                                        </div>
                                    <?php endif; ?>
                                    <div class="flex flex-col gap-2">
                                        <div class="text-sm text-slate-600 font-medium"><?php echo e(@$item->product->name); ?></div>
                                        <div class="flex flex-col gap-1">
                                            <?php $__currentLoopData = $item->addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="text-xs text-slate-500">+ <?php echo e($add->quantity); ?> <?php echo e($add->addon->name); ?></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <?php echo e($item->quantity); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <div class="text-sm text-slate-600 font-medium">
                                    <?php echo e(currency_encode($item->total_price)); ?>

                                </div>
                                <?php if($item->additional_price > 0): ?>
                                    <div class="text-xs text-slate-500 mt-2">
                                        + <?php echo e(currency_encode($item->additional_price)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <div class="text-sm text-slate-600 font-medium">
                                    <?php echo e(currency_encode($item->grand_total)); ?>

                                </div>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-700">
                                <div class="flex">
                                    <?php if($sales->status == "DRAFT"): ?>
                                        <a href="<?php echo e(route('sales.detail.product.delete', [$sales->id, $item->id])); ?>" class="flex items-center p-2 px-3 rounded-lg bg-red-500 text-white" onclick="RemoveProduct(event, '<?php echo e($item); ?>')">
                                            <ion-icon name="trash-outline" class="text-lg"></ion-icon>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th class="px-6 py-4 text-sm text-slate-700 text-left">
                            Total
                        </th>
                        <th class="px-6 py-4 text-sm text-slate-700 text-left" colspan="2">
                            <?php echo e($sales->total_quantity); ?>

                        </th>
                        <th class="px-6 py-4 text-sm text-slate-700 text-left">
                            <?php echo e(currency_encode($sales->total_price)); ?>

                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>
    
<?php if($sales->status == "DRAFT"): ?>
    <?php echo $__env->make('user.sales.detail.add_product', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('user.sales.detail.remove_product', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('user.sales.detail.edit_notes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('user.sales.detail.edit_customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/MultiSelectorAPI.js')); ?>"></script>
<script>
    let product = null;
    const RenderProductSelector = () => {
        select("#ProductSelector").innerHTML = "";
        new MultiSelectorAPI('#ProductSelector', [], {
            fetchUrl: '/api/product/search?branch_id=<?php echo e($sales->branch_id); ?>&q=',
            name: "product_ids",
            label: "Produk",
            single: true,
            parseResponse: (data) => data.products,
            onChoose: datas => {
                chooseProduct(datas[0]);
            }
        });
    }

    const chooseProduct = (prod) => {
        
        select("#ProductSelectorWrapper").classList.add('hidden');
        select("#ProductDetailWrapper").classList.remove('hidden');
        select("#AddProduct #product_id").value = prod.id;
        if (prod.images.length > 0) {
            select("#AddProduct #ProductImage").setAttribute('src', `/storage/product_images/${prod.images[0].filename}`);
        }
        select("#AddProduct #ProductName").innerHTML = prod.name;

        // Render Add Ons
        prod.addons.forEach((item, i) => {
            let el = document.createElement("div");
            el.classList.add("flex", "items-center", "gap-4");
            el.innerHTML = `<div class="text-sm text-slate-700 flex grow">${item.addon.name}</div>
            <input type="number" value="0" name="addon_${i}" id="addon_${i}" addon-data="${btoa(JSON.stringify(item))}" oninput="updateAddOnQty(this)" class="h-10 outline-0 border text-sm w-20 text-center" />`;
            select("#AddProduct #AddOnArea").appendChild(el);
        });

        // Render Prices
        prod.prices.forEach((price, p) => {
            let option = document.createElement('option');
            option.value = price.id;
            option.innerHTML = `${price.label} - ${Currency(price.value).encode()}`;
            select("#AddProduct #product_price_id").appendChild(option);
        })
        
    }
    
    let addons = [];
    const updateAddOnQty = (target) => {
        let selectedAddOn = JSON.parse(atob(target.getAttribute('addon-data')));
        let quantity = target.value;

        if (addons.length === 0) {
            addons.push({
                id: selectedAddOn.addon.id,
                quantity: quantity,
            });
        } else {
            
            addons.forEach((addon, a) => {
                if (addon.id === selectedAddOn.addon.id) {
                    addons[a]['quantity'] = quantity;
                } else {
                    addons.push({
                        id: selectedAddOn.addon.id,
                        quantity: quantity,
                    });
                }
            });
        }

        select("#AddProduct #addons").value = JSON.stringify(addons);
        
    }
    const CancelChooseProduct = () => {
        RenderProductSelector();
        select("#AddProduct #product_id").value = "";
        select("#ProductSelectorWrapper").classList.remove('hidden');
        select("#ProductDetailWrapper").classList.add('hidden');
    }

    RenderProductSelector();

    const RemoveProduct = (event, data) => {
        event.preventDefault();
        const link = event.currentTarget;
        data = JSON.parse(data);
        select("#RemoveProduct form").setAttribute('action', link.href);
        select("#RemoveProduct #name").innerHTML = data.product.name;

        toggleHidden("#RemoveProduct");
    }

    const EditNotes = (id, notes) => {
        select("#EditNotes #id").value = id;
        select("#EditNotes #notes").value = notes;
        toggleHidden('#EditNotes');
    }

    if (select('#CustomerSelector') !== null) {
        new MultiSelectorAPI('#CustomerSelector', [], {
            fetchUrl: '/api/customer/search?branch_id=<?php echo e($sales->branch_id); ?>&q=',
            name: "customer_ids",
            label: "Pelanggan",
            single: true,
            parseResponse: (data) => data.customers // if the response is { categories: [...] }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/sales/detail/index.blade.php ENDPATH**/ ?>