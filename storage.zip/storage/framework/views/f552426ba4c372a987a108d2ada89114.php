<div class="flex flex-col gap-4 bg-white p-8 rounded-lg shadow shadow-slate-200 mt-8">
    <div class="min-w-full overflow-hidden overflow-x-auto p-5">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="text-sm text-slate-700 bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">No.</th>
                    <th scope="col" class="px-6 py-3 text-left">Supplier</th>
                    <th scope="col" class="px-6 py-3 text-left">Status</th>
                    <th scope="col" class="px-6 py-3 text-left">
                        <ion-icon name="create-outline"></ion-icon>
                    </th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <a href="<?php echo e(route('inventory.detail', $inventory->id)); ?>" class="text-primary font-medium">
                                <?php echo e($inventory->label); ?>

                            </a>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php if($inventory->supplier_id == null): ?>
                                -
                            <?php else: ?>
                                <?php echo e($inventory->supplier->name); ?>

                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($inventory->status); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($inventory->notes); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/inventory/inbound.blade.php ENDPATH**/ ?>