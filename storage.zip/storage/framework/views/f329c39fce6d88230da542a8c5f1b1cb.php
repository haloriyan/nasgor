<div class="flex flex-col gap-4 bg-white p-8 rounded-lg shadow shadow-slate-200 mt-8">
    <h3 class="text-xl text-slate-700 font-medium">Produk</h3>
    <div class="min-w-full overflow-hidden overflow-x-auto p-5">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="text-sm text-slate-700 bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">
                        <ion-icon name="image-outline"></ion-icon>
                    </th>
                    <th scope="col" class="px-6 py-3 text-left">Produk</th>
                    <th scope="col" class="px-6 py-3 text-left">Harga Jual</th>
                    <th scope="col" class="px-6 py-3 text-left">Quantity</th>
                    <th scope="col" class="px-6 py-3 text-left"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php if($product->images->count() > 0): ?>
                                <img 
                                    src="<?php echo e(asset('storage/product_images/' . $product->images[0]->filename)); ?>" 
                                    alt="<?php echo e($product->name); ?>" 
                                    class="h-16 aspect-square rounded-lg object-cover"
                                >
                            <?php else: ?>
                                <div 
                                    class="h-16 aspect-square rounded-lg bg-slate-200 flex items-center justify-center"
                                >
                                    <ion-icon name="image-outline" class="text-lg text-slate-700"></ion-icon>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <div><?php echo e($product->name); ?></div>
                            <div class="flex items-center gap-2 text-xs mt-2">
                                <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bg-primary-transparent text-primary p-1 px-3 rounded-full">
                                        <?php echo e($category->name); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e(currency_encode($product->price)); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($product->quantity); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700 flex items-center gap-4">
                            <button class="bg-red-500 text-white flex items-center p-2 px-3 rounded-lg" onclick="DeleteProduct('<?php echo e($product); ?>')">
                                <ion-icon name="trash-outline" class="text-lg"></ion-icon>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/product/produk.blade.php ENDPATH**/ ?>