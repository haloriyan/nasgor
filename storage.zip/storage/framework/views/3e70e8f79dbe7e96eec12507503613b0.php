<?php $__env->startSection('title', "Dashboard"); ?>

<?php
    $availableDateRanges = [
        'today' => "Hari Ini",
        'last_7_days' => "Minggu Ini",
        'this_month' => "Bulan Ini",
        'last_3_months' => "3 Bulan Terakhir",
        'last_6_months' => "6 Bulan Terakhir",
        'this_year' => "Tahun Ini",
        'last_2_years' => "2 Tahun Terakhir"
    ];
    $colors = ['red', 'orange', 'amber', 'yellow', 'lime', 'green', 'emerald', 'teal', 'cyan', 'sky', 'blue', 'indigo', 'violet', 'purple', 'fuchsia', 'pink', 'rose'];
?>
    
<?php $__env->startSection('content'); ?>
<input type="hidden" id="OmsetChartOption" value="<?php echo e(json_encode($omset_chart)); ?>">
<input type="hidden" id="VolumeChartOption" value="<?php echo e(json_encode($volume_chart)); ?>">

<div class="flex items-center justify-end gap-4 p-8 pb-0">
    <div class="flex flex-col grow gap-2 mobile:hidden">
        <h2 class="text-xl text-slate-700 font-medium">Performa untuk Cabangmu</h2>
        <div class="flex items-center gap-2">
            <?php $__currentLoopData = $myBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myBranch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-1 px-3 text-xs text-slate-600 bg-white border rounded">
                    <?php echo e($myBranch->name); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="text-xs">Rentang Waktu</div>
    <select name="date_range" id="date_range" class="text-xs text-slate-600 font-medium border rounded-lg p-3 px-3" onchange="addFilter('date_range', this.value)">
        <?php $__currentLoopData = $availableDateRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($request->date_range == $key ? "selected='selected'" : ""); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="grid grid-cols-4 mobile:grid-cols-1 gap-4 p-8 pb-0">
    <div class="flex flex-col border rounded-lg bg-white">
        <div class="p-8">
            <div class="text-xl text-slate-700 font-medium">
                <?php echo e(currency_encode($omset)); ?>

            </div>
        </div>
        <a href="<?php echo e(route('sales')); ?>" class="flex items-center gap-4 p-4 px-8 bg-blue-100 text-blue-500 rounded-b-lg">
            <ion-icon name="bar-chart-outline" class="text-lg"></ion-icon>
            <div class="flex grow text-xs">Omset</div>
            <ion-icon name="arrow-forward-outline" class="text-lg"></ion-icon>
        </a>
    </div>
    <div class="flex flex-col border rounded-lg bg-white">
        <div class="p-8">
            <div class="text-xl text-slate-700 font-medium">
                <?php echo e(currency_encode($sales->sum('total_margin'))); ?>

            </div>
        </div>
        <a href="<?php echo e(route('sales')); ?>" class="flex items-center gap-4 p-4 px-8 bg-green-100 text-green-500 rounded-b-lg">
            <ion-icon name="cash-outline" class="text-lg"></ion-icon>
            <div class="flex grow text-xs">Keuntungan</div>
            <ion-icon name="arrow-forward-outline" class="text-lg"></ion-icon>
        </a>
    </div>
    <div class="flex flex-col border rounded-lg bg-white">
        <div class="p-8">
            <div class="text-xl text-slate-700 font-medium">
                <?php echo e(currency_encode($spending->sum('total_price'))); ?>

            </div>
        </div>
        <a href="<?php echo e(route('purchasing')); ?>" class="flex items-center gap-4 p-4 px-8 bg-red-100 text-red-500 rounded-b-lg">
            <ion-icon name="people-outline" class="text-lg"></ion-icon>
            <div class="flex grow text-xs">Pengeluaran</div>
            <ion-icon name="arrow-forward-outline" class="text-lg"></ion-icon>
        </a>
    </div>
    <div class="flex flex-col border rounded-lg bg-white">
        <div class="p-8">
            <div class="text-xl text-slate-700 font-medium">
                <?php echo e($lowStocks->count()); ?>

            </div>
        </div>
        <a href="<?php echo e(route('product')); ?>" class="flex items-center gap-4 p-4 px-8 bg-orange-100 text-orange-500 rounded-b-lg">
            <ion-icon name="cube-outline" class="text-lg"></ion-icon>
            <div class="flex grow text-xs">Hampir Habis</div>
            <ion-icon name="arrow-forward-outline" class="text-lg"></ion-icon>
        </a>
    </div>
</div>
<div class="grid grid-cols-2 mobile:grid-cols-1 gap-8 p-8 pb-0">
    <div class="flex flex-col gap-8 grow">
        <div class="bg-white rounded-lg border">
            <div class="flex items-center gap-4 p-6 px-8 border-b">
                <ion-icon name="cash-outline" class="text-2xl text-slate-700"></ion-icon>
                <div class="text-slate-700 flex grow">Omset</div>
            </div>
            <div class="p-8">
                <div id="OmsetChart" class="w-full h-[350px]"></div>
            </div>
        </div>
    </div>
    <div class="flex flex-col gap-8 grow">
        <div class="bg-white rounded-lg border">
            <div class="flex items-center gap-4 p-6 px-8 border-b">
                <ion-icon name="bar-chart-outline" class="text-2xl text-slate-700"></ion-icon>
                <div class="text-slate-700 flex grow">Volume Transaksi</div>
            </div>
            <div class="p-8">
                <div id="VolumeChart" class="w-full h-[350px]"></div>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-3 mobile:grid-cols-1 gap-8 p-8">
    <div class="flex flex-col gap-8 grow">
        <div class="bg-white rounded-lg border">
            <div class="flex items-center gap-4 p-6 px-8 border-b">
                <ion-icon name="cube-outline" class="text-2xl text-slate-700"></ion-icon>
                <div class="text-slate-700 flex grow">Stok Menipis</div>
            </div>
            <div class="p-8 flex flex-col gap-4">
                <?php if(count($lowStocks) == 0): ?>
                    <div class="text-sm text-slate-600">Semua produk masih banyak :)</div>
                <?php endif; ?>
                <?php $__currentLoopData = $lowStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-4">
                        <div class="text-sm text-slate-600 flex grow"><?php echo e($product->name); ?></div>
                        <div class="text-xs text-slate-500">Stok : <?php echo e($product->quantity); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="flex flex-col gap-8 grow">
        <div class="bg-white rounded-lg border">
            <div class="flex items-center gap-4 p-6 px-8 border-b">
                <ion-icon name="bag-outline" class="text-2xl text-slate-700"></ion-icon>
                <div class="text-slate-700 flex grow">Penjualan</div>
            </div>
            <div class="p-8 flex flex-col gap-4">
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $theColor = $colors[rand(0, count($colors) - 1)];
                    ?>
                    <div class="flex items-center gap-4">
                        <div class="w-8 h-8 flex items-center justify-center rounded-lg text-white bg-<?php echo e($theColor); ?>-500">
                            <ion-icon name="person-outline"></ion-icon>
                        </div>
                        <div class="text-sm text-slate-600 flex grow"><?php echo e(@$sale->customer->name ?? "-"); ?></div>
                        <div class="text-xs text-slate-500"><?php echo e(currency_encode($sale->total_price)); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="flex flex-col gap-8 grow">
        <div class="bg-white rounded-lg border">
            <div class="flex items-center gap-4 p-6 px-8 border-b">
                <ion-icon name="chatbubbles-outline" class="text-2xl text-slate-700"></ion-icon>
                <div class="text-slate-700 flex grow">Ulasan</div>
            </div>
            <div class="p-8 flex flex-col gap-4">
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col gap-4 ReviewItem <?php echo e($r != 0 ? 'hidden' : ''); ?>">
                        <div class="flex items-start gap-4">
                            <div class="text-sm text-slate-400 font-medium flex grow"><?php echo e($review->customer->name); ?></div>
                            <div class="flex items-center gap-2">
                                <?php for($i = 0; $i < 5; $i++): ?>
                                    <ion-icon name="star" class="<?php echo e($review->rating <= $i ? 'text-slate-500' : 'text-yellow-500'); ?>"></ion-icon>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <div class="text-xs text-slate-600"><?php echo e($review->body); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center gap-4 mt-4">
                    <div class="flex items-center justify-center gap-4 grow">
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ReviewDot w-3 h-3 border cursor-pointer border-primary <?php echo e($r == 0 ? 'bg-primary' : ''); ?> rounded-full" onclick="ViewReview(<?php echo e($r); ?>)"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="https://cdn.jsdelivr.net/npm/echarts@5.6.0/dist/echarts.min.js" integrity="sha256-v0oiNSTkC3fDBL7GfhIiz1UfFIgM9Cxp3ARlWOEcB7E=" crossorigin="anonymous"></script>
<script>
    const omsetChartOption = JSON.parse(select("#OmsetChartOption").value);
    const omsetChart = echarts.init(
        select("#OmsetChart")
    );
    const volumeChartOption = JSON.parse(select("#VolumeChartOption").value);
    const volumeChart = echarts.init(
        select("#VolumeChart")
    );

    omsetChart.setOption(omsetChartOption);
    volumeChart.setOption(volumeChartOption);

    let reviewIndex = 0;
    let reviewItems = selectAll(".ReviewItem");
    let reviewDots = selectAll(".ReviewDot");
    
    const renderReview = () => {
        reviewItems.forEach(item => item.classList.add('hidden'));
        reviewItems[reviewIndex].classList.remove('hidden');

        reviewDots.forEach(dot => dot.classList.remove('bg-primary'));
        reviewDots[reviewIndex].classList.add('bg-primary')
    }
    const handleReviewInterval = () => {
        if (reviewIndex + 1 === reviewItems.length) {
            reviewIndex = 0;
        } else {
            reviewIndex++;
        }
        renderReview();
    };
    let reviewInterval = setInterval(handleReviewInterval, 6000);

    const ViewReview = (index) => {
        reviewIndex = index;
        renderReview();
        clearInterval(reviewInterval);
        let reviewInterval = setInterval(handleReviewInterval, 6000);
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/dashboard.blade.php ENDPATH**/ ?>