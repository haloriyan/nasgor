<?php $__env->startSection('title', "Detail"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="p-8 flex flex-col gap-4">
    <div class="flex items-center gap-4">
        <a href="<?php echo e(route('accessRole')); ?>">
            <ion-icon name="arrow-back-outline" class="text-xl text-slate-700"></ion-icon>
        </a>
        <h1 class="text-xl text-slate-700 font-bold"><?php echo e(ucwords($role->name)); ?></h1>
        <div class="flex grow"></div>
        <button class="bg-red-500 text-white text-sm font-medium rounded-lg p-3 px-6">
            Hapus
        </button>
    </div>

    <div class="flex items-center w-full p-2 bg-white rounded-lg">
        <a href="?tab=resources" class="p-3 px-6 rounded-lg text-sm <?php echo e(($tab == '' || $tab == 'resources') ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
            Resource
        </a>
        <a href="?tab=users" class="p-3 px-6 rounded-lg text-sm <?php echo e($tab == 'users' ? 'text-primary font-medium bg-primary-transparent' : 'text-slate-600'); ?>">
            Akses
        </a>
        <div class="flex grow"></div>
        <?php if($tab == "users"): ?>
            <button class="p-3 px-5 rounded-lg text-xs bg-green-500 text-white font-bold" onclick="toggleHidden('#AssignUser')">
                Tetapkan Orang
            </button>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('user.accessRole.' . $tab, [
        'role' => $role,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>
    
<?php echo $__env->make('user.accessRole.assign_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/MultiSelectorAPI.js')); ?>"></script>
<script>
    new MultiSelectorAPI('#UserSelector', [], {
        fetchUrl: '/api/user/search?q=',
        name: "user_ids",
        label: "Staff",
        parseResponse: (data) => data.users // if the response is { categories: [...] }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/accessRole/detail.blade.php ENDPATH**/ ?>