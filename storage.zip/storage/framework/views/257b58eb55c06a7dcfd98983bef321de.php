<?php $__env->startSection('title', "Cabang"); ?>
    
<?php $__env->startSection('content'); ?>
<div class="p-8 mobile:p-4 flex flex-col gap-8 mobile:gap-4">
    <div class="flex items-center gap-4 p-4 rounded-lg bg-white">
        <form class="flex mobile:flex-row-reverse items-center gap-4 grow">
            <input type="text" class="w-full h-12 outline-0 text-sm text-slate-700 px-4" placeholder="Cari cabang">
            <button>
                <ion-icon name="search-outline" class="text-xl text-slate-500"></ion-icon>
            </button>
        </form>
        <button class="bg-green-500 text-white text-sm font-medium flex items-center gap-4 mobile:gap-2 p-3 px-6 mobile:px-4 rounded-lg" onclick="toggleHidden('#Create')">
            <ion-icon name="add-outline" class="text-xl"></ion-icon>
            Cabang
        </button>
    </div>

    <?php if($message != ""): ?>
        <div class="bg-green-500 text-white text-sm p-4 rounded-lg">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <div class="min-w-full overflow-hidden overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="text-sm text-slate-700 bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left">Nama</th>
                    <th scope="col" class="px-6 py-3 text-left">
                        <ion-icon name="location-outline"></ion-icon>
                    </th>
                    <th scope="col" class="px-6 py-3 text-left">
                        <ion-icon name="people-outline"></ion-icon>
                    </th>
                    <th scope="col" class="px-6 py-3 text-left"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b">
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <div class="flex items-center gap-4">
                                <?php if($branch->icon == null): ?>
                                    <div class="w-14 h-14 bg-slate-200 rounded-lg flex items-center justify-center">
                                        <ion-icon name="image-outline" class="text-xl text-slate-600"></ion-icon>
                                    </div>
                                <?php else: ?>
                                    <img
                                        class="w-14 h-14 rounded-lg object-cover"
                                        src="<?php echo e(asset('storage/branch_icons/' . $branch->icon)); ?>"
                                        alt="<?php echo e($branch->name); ?>"
                                    >
                                <?php endif; ?>
                                <div><?php echo e($branch->name); ?></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($branch->address); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <?php echo e($branch->accesses->count()); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-slate-700">
                            <div class="flex items-center gap-2">
                                <a href="<?php echo e(route('branches.detail', $branch->id)); ?>">
                                    <button class="p-2 px-4 rounded-lg text-white bg-primary flex items-center">
                                        <ion-icon name="eye-outline" class="text-lg"></ion-icon>
                                    </button>
                                </a>
                                <button class="p-2 px-4 rounded-lg text-white bg-red-500 flex items-center" onclick="Delete('<?php echo e($branch); ?>')">
                                    <ion-icon name="trash-outline" class="text-lg"></ion-icon>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ModalArea'); ?>
    
<?php echo $__env->make('user.branch.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('user.branch.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    const getLocation = () => {
        console.log('getting location...');

        navigator.geolocation.getCurrentPosition(
            res => {
                let coords = res.coords;
                select("#latitude").value = coords.latitude;
                select("#longitude").value = coords.longitude;
            },
            err => {
                console.error('Geolocation error:', err);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    }

    const Delete = data => {
        data = JSON.parse(data);
        select("#Delete #name").innerHTML = data.name;
        select("#Delete #id").value = data.id;
        toggleHidden("#Delete");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Riyan Satria/project/nasigoreng/resources/views/user/branch/index.blade.php ENDPATH**/ ?>